<?php

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

?>

    <div id="gf-infobox">
        <div class="gf-info-overlay"></div>
        <div class="gf-info-inner">
            <div class="gf-infobox-msg"></div>
        </div>
    </div>

</div><!-- gf-wrap -->