<?php

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

?>

<div id="gf-banner-wrap">

    <div id="gf-banner" class="gf-banner-sticky">
        <h2><span><?php echo __('Addons for Beaver Builder', 'gf-grid-module'); ?></span><?php echo __('Plugin Documentation', 'gf-grid-module') ?></h2>
    </div>

</div>