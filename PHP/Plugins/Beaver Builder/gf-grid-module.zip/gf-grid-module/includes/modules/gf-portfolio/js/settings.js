(function($){

	FLBuilder.registerModuleHelper('gf-portfolio', {

		rules: {
			'gutter': {
				number: true
			},
			'tablet_gutter': {
				number: true
			},
            'tablet_gutter': {
                number: true
            },
			'mobile_gutter': {
				number: true
			},
			'mobile_width': {
				number: true
			},
			'per_line': {
				number: true
			},
			'posts_per_page': {
				number: true
			},
		},

	});

})(jQuery);
