jQuery('.header-flag-wrap')
    .appendTo('.fl-page-header-wrap');