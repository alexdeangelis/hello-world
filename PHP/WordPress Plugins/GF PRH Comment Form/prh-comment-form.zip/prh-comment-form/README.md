prh-comment-form
============

Plugin to customize the comment form in WordPress
